
'''
movTagVect = getGenreMovieTags(input('Enter the Genre: '))
print(movTagVect)
for movie in movTagVect:
	print("movie: ",movie)
	print("movie value: ",movTagVect[movie])
	for tag in movTagVect[movie]:
		print("tag:", tag)
		print("tag value: ", movTagVect[movie][tag])
'''